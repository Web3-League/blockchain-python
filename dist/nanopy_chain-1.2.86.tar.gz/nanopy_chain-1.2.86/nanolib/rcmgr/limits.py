"""
Resource limits and enums.

This module provides common enums and types used across
the resource management system.
"""

__all__: list[str] = []
