"""NanoLib peer module."""

# Lazy imports to avoid circular dependencies
# Import directly from submodules when needed:
# from nanolib.peer.id import ID
# from nanolib.peer.peerinfo import PeerInfo, info_from_p2p_addr
# from nanolib.peer.peerdata import PeerData
# from nanolib.peer.peerstore import PeerStore, PeerStoreError, create_signed_peer_record
