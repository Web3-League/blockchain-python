from nanolib.io.exceptions import (
    IOException,
)


class RawConnError(IOException):
    pass
