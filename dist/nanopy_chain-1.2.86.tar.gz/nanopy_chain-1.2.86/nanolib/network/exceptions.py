from nanolib.exceptions import (
    BaseLibp2pError,
)


class SwarmException(BaseLibp2pError):
    pass
