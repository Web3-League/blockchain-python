"""Protocol buffer definitions for Bitswap."""
