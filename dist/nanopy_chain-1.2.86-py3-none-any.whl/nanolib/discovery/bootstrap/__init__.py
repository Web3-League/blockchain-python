"""Bootstrap peer discovery module for py-libp2p."""

from .bootstrap import BootstrapDiscovery

__all__ = ["BootstrapDiscovery"]
