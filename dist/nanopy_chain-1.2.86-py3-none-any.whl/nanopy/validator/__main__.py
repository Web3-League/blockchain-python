#!/usr/bin/env python3
"""Allow running with: python -m nanopy.validator"""
from .main import main

if __name__ == "__main__":
    main()
