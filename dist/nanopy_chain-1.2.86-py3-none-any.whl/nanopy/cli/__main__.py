#!/usr/bin/env python3
"""Allow running with: python -m nanopy.cli"""
from .main import main

if __name__ == "__main__":
    main()
