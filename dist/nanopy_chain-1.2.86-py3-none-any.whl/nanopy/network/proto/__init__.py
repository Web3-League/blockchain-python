# NanoPy P2P Protocol Buffers
# To regenerate: protoc --python_out=. messages.proto
